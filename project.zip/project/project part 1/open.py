fo = open(".txt", "wb")
print("Name of the file: ", fo.name)
